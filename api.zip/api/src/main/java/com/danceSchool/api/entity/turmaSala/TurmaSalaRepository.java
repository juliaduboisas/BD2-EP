package com.danceSchool.api.entity.turmaSala;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TurmaSalaRepository extends JpaRepository<TurmaSala, Integer> {
}
