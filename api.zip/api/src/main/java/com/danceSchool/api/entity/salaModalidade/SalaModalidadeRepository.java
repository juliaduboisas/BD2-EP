package com.danceSchool.api.entity.salaModalidade;

import com.danceSchool.api.entity.id.SalaModalidadeId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalaModalidadeRepository extends JpaRepository<SalaModalidade, SalaModalidadeId> {
}
