package com.danceSchool.api.enums;

public enum Nivel {
    Iniciante,
    Intermediário,
    Avançado
}
