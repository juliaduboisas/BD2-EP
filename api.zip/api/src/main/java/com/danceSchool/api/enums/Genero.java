package com.danceSchool.api.enums;

public enum Genero {
    F, // feminino
    M, // masculino
    O, // outro
    N; // N/I
}
