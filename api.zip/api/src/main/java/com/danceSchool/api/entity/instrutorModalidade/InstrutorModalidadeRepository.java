package com.danceSchool.api.entity.instrutorModalidade;

import com.danceSchool.api.entity.id.InstrutorModalidadeId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InstrutorModalidadeRepository extends JpaRepository<InstrutorModalidade, InstrutorModalidadeId> {
}
