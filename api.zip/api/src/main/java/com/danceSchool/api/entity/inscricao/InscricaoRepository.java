package com.danceSchool.api.entity.inscricao;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InscricaoRepository extends JpaRepository<Inscricao,Integer> {
}
