package com.danceSchool.api.entity.transacaoEntrada;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoEntradaRepository extends JpaRepository<TransacaoEntrada, Integer> {
}
