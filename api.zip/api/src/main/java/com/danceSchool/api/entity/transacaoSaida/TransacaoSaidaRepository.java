package com.danceSchool.api.entity.transacaoSaida;

import org.springframework.data.jpa.repository.JpaRepository;

public interface TransacaoSaidaRepository extends JpaRepository<TransacaoSaida, Integer> {
}
