package com.danceSchool.api.entity.instrutor;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InstrutorRepository extends JpaRepository<Instrutor,String> {
}
